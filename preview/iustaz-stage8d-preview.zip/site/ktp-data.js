window.ktpPlans = window.ktpPlans || {};
