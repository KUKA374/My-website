"""Loopback-only iUSTAZ preview. No production authentication or network writes.
Usage: python start_preview.py [--root /path/to/My-website] [--port 8000]
Default root: the bundled site/ folder. No repository file is changed.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
import argparse
import html
import json
import re

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent/'site')
parser.add_argument('--port',type=int,default=8000)
args=parser.parse_args();ROOT=args.root.resolve()
if not (ROOT/'lesson-materials/content/6/math/q1/10.json').is_file():parser.error('Stage 8D site root not found. Use --root or extract the bundled site/.')

AUTH=r'''/* LOCAL PREVIEW ONLY: teacher stub; no production Firebase configuration. */
(() => {
 const profile={uid:'iustaz-local-preview-teacher',role:'teacher',name:'Preview мұғалімі'};
 const user={uid:profile.uid,displayName:profile.name,email:'preview@example.invalid'};
 const blocked=()=>{throw new Error('Preview режимінде серверлік жазуға тыйым салынған.');};
 const auth={currentUser:user,onAuthStateChanged(fn){queueMicrotask(()=>fn(user));return()=>{};},signOut:async()=>{}};
 const sdk={apps:[{}],initializeApp(){return sdk;},auth:()=>auth,firestore:()=>({collection:name=>({doc:id=>({get:async()=>({exists:name==='users'&&id===profile.uid,data:()=>({...profile})}),set:blocked,update:blocked,delete:blocked}),add:blocked})})};
 window.firebase=sdk;window.FIREBASE_CONFIG={};window.FIREBASE_CONFIGURED=false;
 window.ensureFirebase=async()=>sdk;window.getCurrentUser=()=>({...profile});
 window.requireAuth=()=>({...profile});window.requireRole=roles=>roles.includes('teacher')?({...profile}):null;
 window.getRoleName=()=> 'Preview мұғалімі';window.logoutUser=()=>{location.href='preview.html';};
 window.loginUser=async()=>({success:false,message:'Бұл preview-де кіру қажет емес. /preview.html ашыңыз.'});
 window.routeAfterLogin=()=>{location.href='preview.html';};
})();'''

def landing():
 rows=[]
 for n in range(1,11):
  data=json.loads((ROOT/f'lesson-materials/content/6/math/q1/{n}.json').read_text());ref=data['presentation']
  rows.append(f'<li><a href="lesson-material.html?class=6&amp;subject=math&amp;quarter=1&amp;lesson={n}">№{n} сабақ — толық материал</a> <small>{len(data["examples"])} мысал · 15 тапсырма · {ref["startSlide"]}–{ref["endSlide"]} слайд</small></li>')
 return '''<!doctype html><html lang="kk"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>iUSTAZ · Stage 8D Preview</title><link rel="stylesheet" href="iustaz-ui.css"><style>body{max-width:900px;margin:32px auto;padding:0 20px;background:#faf8ff;color:#241c35;font:18px/1.7 system-ui}a{color:#6430c6}li{padding:9px}small{display:block;color:#62556f}aside{padding:20px;background:white;border:1px solid #ded2f3;border-radius:16px}nav{display:flex;gap:20px;flex-wrap:wrap}</style><h1>iUSTAZ — №1–10 сабақтар</h1><aside><strong>Жергілікті preview. Production емес.</strong><p>Stage 8D commit: 297f8ea. Тесттік мұғалім профилі қолданылады; нақты аккаунтқа кіру қажет емес. Firebase сұраулары мен серверлік жазу бұғатталған. Жеке өзгерістер тек осы браузерде сақталады.</p></aside><nav><a href="index.html#classes">Сыныптар каталогы</a><a href="class.html?class=6&amp;subject=math&amp;quarter=1">6-сынып · І тоқсан КТП</a><a href="games.html">20 ойын</a></nav><ol>'''+''.join(rows)+'''</ol><p>Каталог жолы: Сыныптар → 6-сынып → Математика, 1-тоқсан → сабақ → «Модульдік сабақ көрінісі (демо)».</p><p>Тізімдегі №11–39 модульдік материалдары әзірге дайын емес. Видеолар қосылмаған.</p></html>'''

BANNER='''<div data-preview-banner style="padding:10px 16px;background:#f0e9ff;color:#382052;border-bottom:1px solid #d9c8f7;font:14px/1.5 system-ui;overflow-wrap:anywhere"><a href="preview.html" style="color:inherit">← №1–10 сабақтар</a> · ЖЕРГІЛІКТІ PREVIEW · тесттік мұғалім · Firebase production өшірулі</div>'''
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def end_headers(self):
  self.send_header('Cache-Control','no-store')
  self.send_header('Content-Security-Policy',"connect-src 'self'; frame-src 'none'; object-src 'none'; form-action 'self'")
  self.send_header('Referrer-Policy','no-referrer')
  self.send_header('X-Content-Type-Options','nosniff')
  super().end_headers()
 def payload(self,data,kind):
  b=data.encode();self.send_response(200);self.send_header('Content-Type',kind+'; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers()
  if self.command!='HEAD':self.wfile.write(b)
 def do_HEAD(self):self.do_GET()
 def do_GET(self):
  name=urlsplit(self.path).path
  p=(ROOT/name.lstrip('/')).resolve()
  if not p.is_relative_to(ROOT) or any(s.startswith('.')or s in ['node_modules','__pycache__'] for s in p.relative_to(ROOT).parts):self.send_error(403);return
  if name in ['/', '/preview.html']:return self.payload(landing(),'text/html')
  if name=='/auth.js':return self.payload(AUTH,'application/javascript')
  if name=='/firebase-config.js':return self.payload('window.FIREBASE_CONFIG={};window.FIREBASE_CONFIGURED=false;','application/javascript')
  if p.is_file()and p.suffix=='.html':
   text=p.read_text()
   text=re.sub(r'<script\b[^>]*src=["\']https://www\.gstatic\.com/firebasejs/[^"\']+["\'][^>]*>\s*</script>','',text,flags=re.I)
   text=re.sub(r'(<body\b[^>]*>)',lambda m:m.group(1)+BANNER,text,count=1,flags=re.I)
   return self.payload(text,'text/html')
  if p.is_dir():self.send_error(404);return
  super().do_GET()
 def do_POST(self):self.send_error(405,'Preview is read-only')
 do_PUT=do_PATCH=do_DELETE=do_POST

print(f'Preview only: http://127.0.0.1:{args.port}/preview.html',flush=True)
print('Root:',ROOT,'| Firebase production disabled | Ctrl+C to stop',flush=True)
try:ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
except KeyboardInterrupt:pass
